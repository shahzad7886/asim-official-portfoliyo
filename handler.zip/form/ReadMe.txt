Author: CodexWorld
Author URL: http://www.codexworld.com/
Author Email: contact@codexworld.com
Tutorial Link: http://www.codexworld.com/new-google-recaptcha-with-php/

============ Instructions ============
1. Register your site at the Google reCAPTCHA admin console - https://www.google.com/recaptcha/admin

2. Collect your Site Key and Secret Key.

3. In the "submit.php" file: 
===> Specify the Site Key ($siteKey) and Secret Key ($secretKey). 
===> Specify the recipient email address in $recipientEmail variable to get the email notification on contact form submission.

4. Open the index.php file on the browser and test the Google reCAPTCHA functionality.


============ May I Help You ===========
Do reach out to us @ support@codexworld.com if you have any trouble implementing this or if you need any help.

If you have any queries about this script, send the query by posting a comment here - http://www.codexworld.com/new-google-recaptcha-with-php/#respond